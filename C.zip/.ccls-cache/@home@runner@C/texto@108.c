//108) Fazer um programa para cadastrar os produtos de uma loja com os seguintes dados:
//código, descrição, estoque atual e preço. Mostrar todos os produtos com estoque abaixo de 10.

#include <stdio.h>
#include <string.h>
#define tam 10
// tam vai ser a quantidade de produtos lidos, portanto apenas alterar e i  vai mostrar qual o numero na lista

struct loja {
 char codgo[tam]; // considerando que podia ter letras
 char descricao[tam];
 int  estoque ;
 int preco ;
}typedef tudo;

int main() {

  tudo vtudo[tam];
  int i;

for (i=0;i<3;i++){
  printf("\n informacoes produto %d\n",i);
      printf("Digite o codgo: ");
      gets(vtudo[i].codgo);
      printf("Digite a descricao: ");
      gets(vtudo[i].descricao);
      printf("Digite o estoque: ");
      scanf("%d",&vtudo[i].estoque);
      printf("Digite o preco: ");
      scanf("%d",&vtudo[i].preco);
      __fpurge(stdin);
}

for (i=0;i<3;i++){
  int est =vtudo[i].estoque;
  if ( est < 10){
  printf("\n estoque baixo no produto com codgo %s \n",vtudo[i].codgo);
}
  }
   return 0;
}