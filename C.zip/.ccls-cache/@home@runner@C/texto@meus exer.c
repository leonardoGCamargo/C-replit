Aluno 10 da chamada:	
 - Lista 1: 27, 28, 12, 	
 - Lista 2: 71, 84, 73, 	
 - Lista 3: 102, 108, 101, 	
 - Lista 4: 118, 111, 112, 


12. Um funcionário de uma empresa recebeu um abono de 20% sobre o seu salário atual
e mais uma comissão de 10.000,00. Sobre esse total (abono + comissão) recebeu um
aumento de 35%. Calcule o valor do abono, do aumento e do salário final (mês atual)
após estes reajustes, ao ser fornecido pelo usuário o valor do salário atual.

27. Faça um programa que determina e apresenta o Grau de Obesidade de uma pessoa.
Para isso o usuário deve informar o peso e a altura da pessoa. O Grau de Obesidade é
determinado pelo Índice da Massa Corpórea, calculador por meio da tabela abaixo:
ÍNDICE DE MASSA
CORPÓREA (IMC)
GRAU DE
OBESIDADE
< 26 Normal
>= 26 e < 30 Obeso
>= 30 Obeso Mórbido
 
28. Leia do usuário dois valores inteiros e efetuar a soma destes valores. Caso o valor
encontrado na soma:
 a) Seja maior ou igual a 10, este valor deverá ser somado de 5;
 b) Não seja maior ou igual a 10, este valor deverá ser subtraído de 5;
Por fim apresente o valor final.

71) Leia do usuário duas palavras com no máximo 20 caracteres cada e mostrar a 1a palavra sem os cinco
primeiros caracteres e a 2a palavra sem os últimos dez caracteres.

73) Leia do usuário os nomes de três pessoas. Depois informe esses nomes em ordem alfabética.

84) Leia do usuário o nome completo de uma pessoa, apresentá-lo no seguinte formato (à direita):
João da Silva Pereira => PEREIRA, João
Maria Cristina Santos Farias => FARIAS, Maria

101-102 ver na lista 
108) Fazer um programa para cadastrar os produtos de uma loja com os seguintes dados:
código, descrição, estoque atual e preço. Mostrar todos os produtos com estoque abaixo de
10.

111) Implemente um programa com uma função que, sendo informados dois valores inteiros, o mesmo realize
a troca dos valores entre as duas variáveis.
112) Desenvolva um programa que simule o sorteio da Mega-Sena (6 números de 0 a 60), ou seja, ela deve
retornar um valor aleatório entre 1 e 60, o qual deve ser apresentado em tela. Utilize uma função que
retorne esse número aleatório. Utilize as seguintes funções da biblioteca <time.h>, disponíveis no link
abaixo:
a) srand(time(0))
b) rand();
Detalhes e exemplos acesse: <http://www.cplusplus.com/reference/cstdlib/rand/>.

118) Você precisa armazenar uma serie finita de temperaturas médias diárias da cidade de Foz do Iguaçu.
Considere que um mês tem 30 dias e, ao todo, foram coletadas N temperaturas a partir do dia 1º de
Janeiro. Você necessita implementar uma função para cada solicitação abaixo:
a) Realizar a leitura e armazenamento das N temperaturas, sendo N previamente informado;
b) Calcular e retornar a maior temperatura;
c) Calcular e retornar a menor temperatura;
d) Caso sejam coletadas temperaturas suficientes para completar o mês, calcule e retorne a média das
temperaturas mensais;
e) Calcular e retornar a quantidade de dias em que a temperatura foi maior que 30º.
f) Apresentar as N temperaturas coletadas. 