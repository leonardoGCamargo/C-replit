//12. Um funcionário de uma empresa recebeu um abono de 20% sobre o seu salário atual
//e mais uma comissão de 10.000,00. Sobre esse total (abono + comissão) recebeu um
//aumento de 35%. Calcule o valor do abono, do aumento e do salário final (mês //atual)
//após estes reajustes, ao ser fornecido pelo usuário o valor do salário atual.

#include <stdio.h>


int main(void) {
  int num1, num2, num3, num4;
  printf(" diga seu salario \n ");
  scanf("%d",&num1);
  num2 = num1-(num1/5);
  num3 = num2+10000 ;
  num4= num3 + (num3*35/100) ;
printf(" seu salario com o abono é %d \n ",num2);
  printf(" seu salario com o abono  e comissão eh %d \n ",num3);
 
  printf(" seu salario com o aumento apos tudo eh %d \n ",num4);
    return 0;
}

