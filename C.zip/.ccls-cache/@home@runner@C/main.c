#include <stdio.h>


int main(void) {
  float a;
  float b;
  float result;
  
  a=17;
  
  printf("type your distance traveled:\n");
  scanf("%f",&b);
  result=a*b;
 printf("knowing your car do %.2f km per liter, and you have had just spent %.2f L , in  %.2f km",a,result,b);

    return 0;
}
