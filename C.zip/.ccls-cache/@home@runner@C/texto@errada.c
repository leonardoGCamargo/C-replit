#include <stdio.h>


int main(void) {
int n1,n2,n3,n4,n5,n6,n7,n8, n9, n10 ;
n3=0;
n4=0;
  
  
  for (n1= 170; n2<1110; n1++  );

printf(" type your weight \n");
scanf("%f",&n1);

  if(n2>=170){
    n3=n3++ ;
    
  }
  else {
    n4=n4++ ;
    
  }
  printf(" a quantidade de maiores é %d  e a quantidade de menores é %d \n", n3, n4) ;
    

    return 0;
}
