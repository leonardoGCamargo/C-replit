////Você precisa armazenar uma serie finita de temperaturas médias diárias da cidade de Foz do Iguaçu.
//Considere que um mês tem 30 dias e, ao todo, foram coletadas N temperaturas a partir do dia 1º de
//Janeiro. Você necessita implementar uma função para cada solicitação abaixo:
//a) Realizar a leitura e armazenamento das N temperaturas, sendo N previamente informado;
//b) Calcular e retornar a maior temperatura;
//c) Calcular e retornar a menor temperatura;
//d) Caso sejam coletadas temperaturas suficientes para completar o mês, calcule e retorne a média das
//temperaturas mensais;
//e) Calcular e retornar a quantidade de dias em que a temperatura foi maior que 30º.
//f) Apresentar as N temperaturas coletadas. 

#include <stdio.h>  

#define tam 30

//a)
void cad(float vetor[],int N){
int i;
  for(i=0;i<N;i++){
    printf("fale as temperaturas: \n");
    scanf("%f",&vetor[i]);
    
  }
  
}
//b)
float mav(float vetor[],int N){
  float maior;
  int i;
  maior=vetor[0];
  for (i=0;i<N;i++){
    if (maior<vetor[i]){
      maior=vetor[i];
    }
  }
return maior;
  }

//c)
float mev(float vetor[],int N){
  float menor;
  int i;
  menor=vetor[0];
  for (i=0;i<N;i++){
    if (menor>vetor[i]){
      menor=vetor[i];
    }
  }
return menor;
  }

//f)
void imprime (float vetor[],int N){
int i;
  for(i=0;i<N;i++){
    printf("as temperaturas %d:  %.2f: \n",i, vetor[i]);
    
    
  }
  
}
//d)
float media(float vetor[],int N){
  float soma=0 ;
  int i;

  for (i=0;i<N;i++){
      soma=soma+vetor[i]   ;
  }
return soma/N;
  }
//e)
void dias(float vetor[],int N){
  float d;
  int i;

  for (i=0;i<N;i++){
    
    
    if ( vetor[i]>=30){
      
    printf(" \n %1.f \n",vetor[i]);
    }
  }
  
  }

  

int main(void) {
  
float vtemp[tam];

  printf(" considerando N = 30 pois adimitimos que o mes tenha 30 dias \n");
  cad(vtemp,tam);
  printf(" \n imprimindo os valores digitados");
  imprime(vtemp,tam);
  printf(" \n caclculando o maior valor de temperatura \n");
  printf(" maior valor = %2.f \n", mav(vtemp,tam));
  printf(" menor valor = %2.f \n", mev(vtemp,tam));
  printf("a media é = %2.f \n ", media(vtemp,tam));
 printf(" os dias com temp> 30 são  \n ");
  dias(vtemp, tam);
  
  
  
  
    return 0;
}

//112) Desenvolva um programa que simule o sorteio da Mega-Sena (6 números de 0 a 60), ou seja, ela deve
//retornar um valor aleatório entre 1 e 60, o qual deve ser apresentado em tela. Utilize uma função que
//retorne esse número aleatório. Utilize as seguintes funções da biblioteca <time.h>, disponíveis no link
//abaixo:
//a) srand(time(0))
//b) rand();
//Detalhes e exemplos acesse: <http://www.cplusplus.com/reference/cstdlib/rand/>.

#include <stdio.h>      
#include <stdlib.h>     
#include <time.h>   
#define tam 1

void cad(float vetor[],int N){
int i;
  for(i=0;i<N;i++){
int iSecret, iGuess, a, b, c, d, e, f;

a= rand() % 60;
b= rand() % 60;
c= rand() % 60;
d= rand() % 60;
e= rand() % 60;
f= rand() % 60;
  printf (" %d %d %d %d %d %d  ", a, b, c, d, e, f);

int main ()
{
float vtemp[tam];
  cad(vtemp,tam);

  
  return 0;
}