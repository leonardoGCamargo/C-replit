//101) Declarar um vetor e struct correspondentes cuja representação gráfica é dada a seguir:
//102) Utilizando o vetor de estruturas criado no exercício anterior, faça a atribuição dos valores
//apresentados abaixo aos campos correspondentes:
#include <stdio.h>
#include <string.h>

#define tam 2

struct ma{
    char nvoo[10];
    char tipo[51];
    float preco;
    int lugares; 
}typedef mat;


int main() {

  mat vmat[tam];
  int i;
  
  //for (i=0;i<tam;i++){
  strcpy(vmat[0].nvoo, "XYZA5");
  strcpy(vmat[0].tipo, "economica");
  vmat[0].preco = 395.00;
  vmat[0].lugares = 115;
//    }
//for (i=0;i<tam;i++){
  strcpy(vmat[1].nvoo, "ABCW9");
  strcpy(vmat[1].tipo, "CLASSE");
      vmat[1].preco = 710.00;
      vmat[1].lugares = 28;

//}
   
   for (i=0;i<tam;i++){

   printf("\nImprimindo as informacoes cadastradas:\n");
   for (i=0;i<tam;i++){
     printf("------------------------\n");
     printf("Informacoes do ALUNO %d\n",i);
     printf("Matricula: %s\n",vmat[i].nvoo);
     printf("Nome: %s\n",vmat[i].tipo);
     printf("Nota: %.2f\n",vmat[i].preco);
printf("Nota: %d\n",vmat[i].lugares);
     }

  return 0;
}
  }