// 111) Implemente um programa com uma função que, sendo informados dois valores inteiros, o mesmo realize
// a troca dos valores entre as duas variáveis.

#include <stdio.h>  
#define tam 2

void cad(int a, int b){
int  n ;
 n = a;
  a = b;
  b = n;
  printf(" 1ro vale %d \n o segundo valor vale %d \n", a, b );
  
  }


int main(void) {
  
int a , b ;
printf("digite 1ro valor inteiro \n");
  scanf("%d",&a);
  printf("digite o 2do valor inteiro \n");
  scanf("%d",&b);
  cad(a,b);

  
  

  
  
    return 0;
}

  