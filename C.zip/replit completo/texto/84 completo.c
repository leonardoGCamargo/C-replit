//84) Leia do usuário o nome completo de uma pessoa, apresentá-lo no seguinte formato (à direita):
//João da Silva Pereira => PEREIRA, João
//Maria Cristina Santos Farias => FARIAS, Maria

#include <stdio.h>
#include <string.h>

//string.h
#define tam 80
int main() {

  int esp1, esp2;
char nome1[tam];
  char nomef[tam] ;
  char nome [tam];
  int i;
printf(" diga seu nome completo \n ");
  gets(nome);
  int comp= strlen(nome);
  for (i=0;i<tam;i++){
     if(nome[i]==' ') {
       esp2 = i;
       }
  }  
for (i=comp;i>=0;i--){
     if(nome[i]==' ' ) {
       esp1 = i;
       } }
for (i=esp2+1;i<=comp-1;i++){

  nomef[i-esp2-1]=nome[i];
 
     }
    
  for (i=0;i<esp1;i++){

  nome1[i]=nome[i];
  
    
  }
  printf("\n \n %s, %s  \n \n",strupr(nomef),nome1);
 
// esta dando um erro por conta do strupr que seria para deixar maiusculo mas se tira ele da tudo certo.
  return 0;
}