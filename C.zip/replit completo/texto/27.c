#include <stdio.h>


int main(void) {
  float num1, num2, num3 ;
  printf(" type your weight in kg \n ");
  scanf("%f",&num1);
printf(" type your high in m ex:1.72 \n ");
  scanf("%f",&num2);
  num3 =num1/(num2*num2);
  printf(" the value of the imc is %.2f",num3);

if (num3<26){
  printf(" the person is normal \n");
  
}
if ((num3>=26)&&(num3<30)){
  printf(" the person is obse");
}
else
  if (num3>=30)
{ 
  printf("the person is morbid obse");
  }
    return 0;
}

