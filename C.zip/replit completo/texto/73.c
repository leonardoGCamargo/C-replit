// 73) Leia do usuário os nomes de três pessoas. Depois informe esses nomes em
// ordem alfabética.

#include <stdio.h>

char n1[20];
char n2[20];
char n3[20];
char c;
char min[26] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i',
                'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
                's', 't', 'u', 'v', 'x', 'w', 'y', 'z'};
char mai[26] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
                'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
                'S', 'T', 'U', 'V', 'X', 'W', 'Y', 'Z'};
printf("escreva o nome 1");
scanf('%s', &n1);
printf("escreva o nome 2 ");
scanf("%s", &n2);
printf("escreva o nome 3 ");
scanf("%s", &n3);

for (cont = 0; cont < 26; cont++) {
  if (nm1[0] == alf[c] || nm1[0] == alfb[c])
    printf("- %s", nm1);
  if (nm2[0] == alf[c] || nm2[0] == alfb[c])
    printf("- %s", nm2);
  if (nm3[0] == alf[c] || nm3[0] == alfb[c])
    printf("- %s", nm3);
}
return 0;
}
