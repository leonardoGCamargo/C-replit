//28. Leia do usuário dois valores inteiros e efetuar a soma destes valores. Caso o valor
//encontrado na soma:
// a) Seja maior ou igual a 10, este valor deverá ser somado de 5;
// b) Não seja maior ou igual a 10, este valor deverá ser subtraído de 5;
//Por fim apresente o valor final.

#include <stdio.h>


int main(void) {
  int num1, num2, num3, num4,num5 ;
  printf(" type value a \n ");
  scanf("%d",&num1);
printf(" type value b \n ");
  scanf("%d",&num2);
  num3 = num1 + num2;
num4 = num3 + 5;
num5 = num3 - 5;
if (num3>=10){
  printf(" the value is %d \n",num4);
  
}
//a
else
 //b
{ 
  printf("the value is %d \n ",num5);
  }
    return 0;
}

