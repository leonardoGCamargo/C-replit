//71) Leia do usuário 
//duas palavras com no máximo 20 caracteres cada e mostrar a 1a palavra sem oscinco primeiros caracteres e a 2a palavra sem os últimos dez caracteres.

#include <stdio.h>

int main() {

  char a [20], b[20];
  int i;
      printf("Digite a:\n");
      scanf("%s",a);
  printf("Digite b:\n");
      scanf("%s",b);
    
  printf("Impressao de a\n");
  for (i=5;i<=19;i++){
      printf("%c  ",a[i]);
  }

  printf("\n Impressao de b\n");
  for (i=0;i<10;i++){
      printf(" %c ",b[i]);
  }

  //pode não preencher os 20 caracteres
  
  
 
  
  return 0;
}