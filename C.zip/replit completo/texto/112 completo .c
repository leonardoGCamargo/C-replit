//112) Desenvolva um programa que simule o sorteio da Mega-Sena (6 números de 0 a 60), ou seja, ela deveretornar um valor aleatório entre 1 e 60, o qual deve ser apresentado em tela. Utilize uma função queretorne esse número aleatório. Utilize as seguintes funções da biblioteca <time.h>, disponíveis no linkabaixo:a) srand(time(0))b) rand();Detalhes e exemplos acesse<http://www.cplusplus.com/reference/cstdlib/rand/>.

#include <stdio.h>      
#include <stdlib.h>     
#include <time.h>   
#define tam 1

void cad(float vetor[],int N){
int i;
  for(i=0;i<N;i++){
    int iSecret, iGuess, a, b, c, d, e, f;

a= rand() % 60;
b= rand() % 60;
c= rand() % 60;
d= rand() % 60;
e= rand() % 60;
f= rand() % 60;
  printf (" %d %d %d %d %d %d  ", a, b, c, d, e, f);
    }
    
  }
  


int main (void){
    
float v[tam];
  cad(v,tam);

  
  return 0;
}